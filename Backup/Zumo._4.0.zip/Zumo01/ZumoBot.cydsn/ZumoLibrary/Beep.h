#ifndef BEEP_H_
#define BEEP_H_

void Beep(uint32 length, uint8 pitch);

#endif 